const connect_to_db = require('./db');
const Talk = require('./Talk');

module.exports.get_random_talk = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  console.log('Picking a random talk');

  try {
    // 1) Connetti al DB
    await connect_to_db();
    console.log('=> connected');

    // 2) Aggregation: Mongo restituisce un talk intero scelto a caso
    const [randomTalk] = await Talk.aggregate([
      { $sample: { size: 1 } }
      // se vuoi escludere campi che non ti servono, puoi aggiungere:
      // { $project: { internal_id: 0, __v: 0 } }
    ]);

    if (!randomTalk) {
      return callback(null, {
        statusCode: 404,
        headers: { 'Content-Type': 'text/plain' },
        body: 'Nessun talk disponibile.'
      });
    }

    console.log('=> got randomTalk:', randomTalk._id);
    return callback(null, {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(randomTalk)
    });

  } catch (err) {
    console.error('Error fetching random talk:', err);
    return callback(null, {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain' },
      body: 'Errore durante l\'estrazione del talk casuale.'
    });
  }
};
