const connect_to_db = require('./db');
const Talk = require('./Talk');

module.exports.get_related_ids = async (event, context, callback) => {
  context.callbackWaitsForEmptyEventLoop = false;
  console.log('Received event:', JSON.stringify(event, null, 2));

  let body = {};
  if (event.body) {
    try {
      body = JSON.parse(event.body);
    } catch (err) {
      return callback(null, {
        statusCode: 400,
        headers: { 'Content-Type': 'text/plain' },
        body: 'Invalid JSON input.'
      });
    }
  }

  const talkId = body.talk_id || body._id;
  if (!talkId) {
    return callback(null, {
      statusCode: 400,
      headers: { 'Content-Type': 'text/plain' },
      body: 'talk_id is required.'
    });
  }

  try {
    await connect_to_db();
    console.log('=> Fetching talk:', talkId);

    const foundTalk = await Talk.findById(talkId).lean();
    if (!foundTalk) {
      return callback(null, {
        statusCode: 404,
        headers: { 'Content-Type': 'text/plain' },
        body: 'Talk not found.'
      });
    }

    console.log('foundTalk.tags =', foundTalk.tags);

    return callback(null, {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        tags: foundTalk.tags || [],
        related_videos_details: foundTalk.related_videos_details || []
      })
    });
  } catch (err) {
    console.error('Error fetching related_ids:', err);
    return callback(null, {
      statusCode: 500,
      headers: { 'Content-Type': 'text/plain' },
      body: 'Could not fetch related_ids.'
    });
  }
};
