const https = require('https');
const extractor = require('keyword-extractor');

const PAGE_SIZE   = 100;
const NEWSAPI_KEY = 'e44a3a880c4a409a8d352b352492419f'; 

// Fetch a page from NewsAPI
function fetchNewsPage(query, apiKey, page) {
  const url = new URL('https://newsapi.org/v2/everything');
  url.searchParams.set('q', query);
  url.searchParams.set('language', 'en');
  url.searchParams.set('pageSize', PAGE_SIZE);
  url.searchParams.set('page', page);
  url.searchParams.set('apiKey', apiKey);

  return new Promise((resolve, reject) => {
    https.get({
      hostname: url.hostname,
      path: url.pathname + url.search,
      protocol: url.protocol,
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode !== 200) {
          return reject(new Error(`NewsAPI ${res.statusCode}: ${data}`));
        }
        try {
          const json = JSON.parse(data);
          resolve(json.articles || []);
        } catch (err) {
          reject(err);
        }
      });
    }).on('error', reject);
  });
}
  

// Estrai tags da testo
function extractTags(text) {
  return extractor.extract(text, {
    language: 'english',
    remove_digits: true,
    return_changed_case: true,
    remove_duplicates: true
  });
}

// Lambda handler
exports.handler = async (event) => {
  try {
    let { query, pages } = event.queryStringParameters || {};
    if (!query && event.body) {
      const body = JSON.parse(event.body);
      query = body.query;
      pages = body.pages;
    }
    if (!query) {
      return {
        statusCode: 400,
        body: JSON.stringify({ message: 'Missing "query" parameter' })
      };
    }
    const totalPages = parseInt(pages, 10) || 1;

    let allArticles = [];
    for (let page = 1; page <= totalPages; page++) {
      const arts = await fetchNewsPage(query, NEWSAPI_KEY, page);
      if (!arts.length) break;
      allArticles.push(...arts);
    }

    const tagged = allArticles.map(art => {
      const text = [art.title, art.description, art.content]
        .filter(Boolean)
        .join(' ');
      const tags = text
        ? extractTags(text).slice(0, 5)
        : [];
      return {
        source:      art.source?.name,
        author:      art.author,
        title:       art.title,
        description: art.description,
        url:         art.url,
        publishedAt: art.publishedAt,
        content:     art.content,
        tags
      };
    });

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(tagged)
    };

  } catch (err) {
    console.error('Errore interno:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: 'Internal error extracting tags' })
    };
  }
};
