const https = require('https');
const { URL } = require('url');

// Leggi la chiave dall’environment (oppure metti direttamente la stringa)
const NEWS_API_KEY = 'pub_84496b6e10e99ed9af1d5d07f1da19d1a7a6b';

// Helper per fare richieste HTTPS con User-Agent “Mozilla/5.0” e ritornare JSON
function fetchJson(url) {
  return new Promise((resolve, reject) => {
    const options = {
      headers: {
        'User-Agent': 'Mozilla/5.0'
      }
    };

    https.get(url, options, (res) => {
      let data = '';
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          resolve({ status: res.statusCode, body: parsed });
        } catch (err) {
          reject(new Error('Error parsing JSON: ' + err.message));
        }
      });
    }).on('error', err => reject(err));
  });
}

exports.handler = async (event) => {
  try {
    // 1) Recupero il termine di ricerca (keyword) dall’URL (GET) o dal body JSON (POST)
    let keywords = [];

    // Se è GET con query string “?tag=ai,business” (qui “tag” è usato come parola chiave)
    if (event.queryStringParameters && event.queryStringParameters.tag) {
      keywords = event.queryStringParameters.tag
        .split(',')
        .map(t => t.trim())
        .filter(t => t.length > 0);

    // Se è POST con body JSON {"tags": [...]}
    } else if (event.body) {
      let bodyObj;
      try {
        bodyObj = JSON.parse(event.body);
      } catch (_) {
        bodyObj = {};
      }
      // Se bodyObj.tags è array di stringhe…
      if (Array.isArray(bodyObj.tags)) {
        keywords = bodyObj.tags
          .map(t => (typeof t === 'string' ? t.trim() : ''))
          .filter(t => t.length > 0);
      // Se invece è stringa singola, ad es. { "tags": "ai" }
      } else if (typeof bodyObj.tags === 'string' && bodyObj.tags.trim() !== '') {
        keywords = bodyObj.tags
          .split(',')
          .map(t => t.trim())
          .filter(t => t.length > 0);
      }
    }

    // 2) Costruisco l’URL di NewsData.io (/latest restituisce le ultime notizie)
    const url = new URL('https://newsdata.io/api/1/latest');
    url.searchParams.append('apikey', NEWS_API_KEY);
    url.searchParams.append('country', 'it');
    url.searchParams.append('language', 'en');

    // Se ho ricevuto parole chiave, le uso come parametro 'q' per la ricerca full-text
    if (keywords.length) {
      // join con spazio per cercare tutte le parole, o con virgola se si vuole "OR"
      url.searchParams.append('q', keywords.join(' '));
    }

    // 3) Chiamata all’API esterna
    const { status, body } = await fetchJson(url);
    if (status !== 200) {
      return {
        statusCode: status,
        body: JSON.stringify({ error: `API error: ${status}` })
      };
    }

    // 4) Estraggo i risultati che arrivano (body.results è array di articoli)
    const articles = Array.isArray(body.results) ? body.results : [];

    // 5) Arricchisco ogni articolo aggiungendo un campo “tags” coerente
    const enriched = articles.map(article => {
      const categoryField = article.category;
      let articleTags = [];

      // category potrebbe essere array, stringa o undefined
      if (Array.isArray(categoryField) && categoryField.length > 0) {
        articleTags = categoryField.map(c => c.trim()).filter(c => c.length > 0);
      } else if (typeof categoryField === 'string' && categoryField.trim() !== '') {
        articleTags = [categoryField.trim()];
      } else {
        articleTags = ['Uncategorized'];
      }

      return {
        ...article,
        tags: articleTags
      };
    });

    // 6) Non serve filtrare localmente: l’API ha già restituito solo gli articoli che contengono le parole chiave
    //    Ritorniamo direttamente 'enriched'
    return {
      statusCode: 200,
      body: JSON.stringify({ articles: enriched })
    };

  } catch (error) {
    console.error('Error fetching news:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Internal server error retrieving news.' })
    };
  }
};