const https = require('https');
const { URL } = require('url');

// Environment variable
const NEWS_API_KEY = 'pub_84496b6e10e99ed9af1d5d07f1da19d1a7a6b';

// Helper to perform GET requests via https with Mozilla User-Agent and return JSON
function fetchJson(url) {
    return new Promise((resolve, reject) => {
      const options = {
        headers: {
          'User-Agent': 'Mozilla/5.0'
        }
      };
  
      https.get(url, options, (res) => {
        let data = '';
        res.on('data', chunk => { data += chunk; });
        res.on('end', () => {
          try {
            const parsed = JSON.parse(data);
            resolve({ status: res.statusCode, body: parsed });
          } catch (err) {
            reject(new Error('Error parsing JSON: ' + err.message));
          }
        });
      }).on('error', err => reject(err));
    });
  }
  
  exports.handler = async (event) => {
    try {
      // Read tags from event (expect array of strings)
      const tags = Array.isArray(event.tags) ? event.tags : [];
  
      // Build URL for NewsData.io
      const url = new URL('https://newsdata.io/api/1/news');
      url.searchParams.append('apikey', NEWS_API_KEY);
      url.searchParams.append('country', 'it');
      url.searchParams.append('language', 'en');
      if (tags.length) {
        url.searchParams.append('category', tags.join(','));
      }
  
      // Fetch articles from NewsData.io
      const { status, body } = await fetchJson(url);
      if (status !== 200) {
        return {
          statusCode: status,
          body: JSON.stringify({ error: `API error: ${status}` })
        };
      }
  
      const articles = Array.isArray(body.results) ? body.results : [];
  
      // Enrich articles with tags field
      const enriched = articles.map(article => {
        const category = article.category;
        return { ...article, tags: category ? [category] : ['Uncategorized'] };
      });
  
      // Return enriched articles
      return {
        statusCode: 200,
        body: JSON.stringify({ articles: enriched })
      };
  
    } catch (error) {
      console.error('Error fetching news:', error);
      return {
        statusCode: 500,
        body: JSON.stringify({ error: 'Internal server error retrieving news.' })
      };
    }
  };